-- customer_summary

SELECT
    c.customer_id,
    c.name,
    c.email,
    c.city,
    c.company,
    COUNT(o.order_id) AS total_orders,
    COALESCE(SUM(o.total_revenue), 0) AS total_revenue,
    COALESCE(AVG(o.total_revenue), 0) AS average_order_value
FROM customers c
LEFT JOIN orders o
    ON c.customer_id = o.customer_id
GROUP BY
    c.customer_id,
    c.name,
    c.email,
    c.city,
    c.company
ORDER BY total_revenue DESC;


-- region_summary

SELECT
    region,
    COUNT(order_id) AS total_orders,
    SUM(total_revenue) AS total_revenue,
    AVG(total_revenue) AS average_order_value
FROM orders
GROUP BY region
ORDER BY total_revenue DESC;


-- category_summary

SELECT
    category,
    COUNT(order_id) AS total_orders,
    SUM(total_revenue) AS total_revenue,
    AVG(total_revenue) AS average_order_value
FROM orders
GROUP BY category
ORDER BY total_revenue DESC;


-- monthly_sales

SELECT
    month,
    COUNT(order_id) AS total_orders,
    SUM(total_revenue) AS total_revenue
FROM orders
GROUP BY month
ORDER BY month;


-- payment_summary

SELECT
    payment_method,
    COUNT(order_id) AS total_orders,
    SUM(total_revenue) AS total_revenue
FROM orders
GROUP BY payment_method
ORDER BY total_revenue DESC;


-- top_products

SELECT
    product,
    category,
    SUM(quantity) AS total_quantity_sold,
    SUM(total_revenue) AS total_revenue
FROM orders
GROUP BY product, category
ORDER BY total_revenue DESC
LIMIT 10;


